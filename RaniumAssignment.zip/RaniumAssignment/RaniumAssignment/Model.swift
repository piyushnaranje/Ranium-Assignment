//
//  Model.swift
//  RaniumAssignment
//
//  Created by Piyush Naranje on 10/03/22.
//
import Foundation

struct DataModel: Codable {
    let links: Links
    let page: Page
    let sentryObjects: [SentryObject]

    enum CodingKeys: String, CodingKey {
        case links, page
        case sentryObjects = "sentry_objects"
    }
}

struct Links: Codable {
    let next, linksSelf: String

    enum CodingKeys: String, CodingKey {
        case next
        case linksSelf = "self"
    }
}

struct Page: Codable {
    let size, totalElements, totalPages, number: Int

    enum CodingKeys: String, CodingKey {
        case size
        case totalElements = "total_elements"
        case totalPages = "total_pages"
        case number
    }
}

struct SentryObject: Codable {
    let links: SentryObjectLinks
    let spkID, designation, sentryID, fullname: String
    let yearRangeMin, yearRangeMax, potentialImpacts, impactProbability: String
    let vInfinity, absoluteMagnitude, estimatedDiameter, palermoScaleAve: String
    let palermoScaleMax, torinoScale, lastObs, lastObsJd: String
    let urlNasaDetails: String
    let urlOrbitalElements: String
    let isActiveSentryObject: Bool
    let averageLunarDistance: Double?

    enum CodingKeys: String, CodingKey {
        case links
        case spkID = "spkId"
        case designation
        case sentryID = "sentryId"
        case fullname
        case yearRangeMin = "year_range_min"
        case yearRangeMax = "year_range_max"
        case potentialImpacts = "potential_impacts"
        case impactProbability = "impact_probability"
        case vInfinity = "v_infinity"
        case absoluteMagnitude = "absolute_magnitude"
        case estimatedDiameter = "estimated_diameter"
        case palermoScaleAve = "palermo_scale_ave"
        case palermoScaleMax = "Palermo_scale_max"
        case torinoScale = "torino_scale"
        case lastObs = "last_obs"
        case lastObsJd = "last_obs_jd"
        case urlNasaDetails = "url_nasa_details"
        case urlOrbitalElements = "url_orbital_elements"
        case isActiveSentryObject = "is_active_sentry_object"
        case averageLunarDistance = "average_lunar_distance"
    }
}

struct SentryObjectLinks: Codable {
    let nearEarthObjectParent, linksSelf: String

    enum CodingKeys: String, CodingKey {
        case nearEarthObjectParent = "near_earth_object_parent"
        case linksSelf = "self"
    }
}


