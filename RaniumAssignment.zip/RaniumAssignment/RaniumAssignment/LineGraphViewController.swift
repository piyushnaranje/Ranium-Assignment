//
//  LineGraphViewController.swift
//  RaniumAssignment
//
//  Created by Piyush Naranje on 10/03/22.
//

import UIKit
import Charts

class LineGraphViewController: UIViewController,ChartViewDelegate {
    var lineChart = LineChartView()
    var allNasaData = [DataModel]()
    @IBOutlet weak var submitButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Utilities.stylefilledButton(submitButton)
        lineChart.delegate = self
        downloadjson {
            self.printContent(self.allNasaData)
        }
        self.dataFromURL()
    }
    
    public func dataFromURL(){
 
        loadJson(fromURLString: "https://api.nasa.gov/neo/rest/v1/feed?detailed=true&api_key=DEMO_KEY") { (result) in
            switch result {
            case .success(let data):
                print(" ##### \(data)")
            case .failure(let error):
                print("Error \(error)")
            }
        }
    }

    @IBAction func submitAction(_ sender: UIButton) {
        let alrt = UIAlertController(title: "Error", message: "Something went wrong", preferredStyle: .alert)

        let secondAction = UIAlertAction(title: "Ok", style: .destructive) { action in
            print("Error in getting data from API")
        }

                    alrt.addAction(secondAction)
            self.present(alrt, animated: true, completion: nil)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        lineChart.frame = CGRect(x: 0,
                                y: 0,
                                width: self.view.frame.size.width,
                                height: self.view.frame.size.width)
        lineChart.center = view.center
        view.addSubview(lineChart)
        var entries = [ChartDataEntry]()
        for x in 0..<10{
            entries.append(ChartDataEntry(x: Double(x), y: Double(x)))
        }
        let set = LineChartDataSet(entries: entries)
        
        set.colors = ChartColorTemplates.material()
        let data = LineChartData(dataSet: set)
        lineChart.data = data
        
    }
    
    
 
}
    
  
    
