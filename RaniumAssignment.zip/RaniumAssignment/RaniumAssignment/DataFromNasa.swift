//
//  DataFromNasa.swift
//  RaniumAssignment
//
//  Created by Piyush Naranje on 11/03/22.
//

import Foundation


func downloadjson(completed:@escaping () -> ()) {
    let url = URL(string: "https://precisedevelopers.in/mobileapp/getlistcustonmers")
    URLSession.shared.dataTask(with: url!) { data, response, error in
        if error == nil{
            do {
               let newData = try JSONDecoder().decode(DataModel.self, from: data!)
                print(newData)
                DispatchQueue.main.async {
                    completed()
                }
            }
            catch{
                print("I have error")
            }
        }
    } .resume()
}



func loadJson(fromURLString urlString: String, completion: @escaping (Result<Data, Error>) -> Void) {
    if let url = URL(string: urlString) {
        let urlSession = URLSession(configuration: .default).dataTask(with: url) { (data, response, error) in
            if let error = error {
                completion(.failure(error))
            }

            if let data = data {
                completion(.success(data))
            }
        }
        urlSession.resume()
    }
}
